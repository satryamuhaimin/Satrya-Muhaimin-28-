var yakin = confirm("pilih janda atau duda");
var nama = prompt("Siapa nama mu?", "");
alert("hello janda duda")
document.write("<p>hello "+ nama +"</p>");
document.write("<p>hello "+ nama +"</p>");
document.write("<p>hello "+ nama +"</p>");
document.write("<p>hello "+ nama +"</p>");
document.write("<p>hello "+ nama +"</p>");